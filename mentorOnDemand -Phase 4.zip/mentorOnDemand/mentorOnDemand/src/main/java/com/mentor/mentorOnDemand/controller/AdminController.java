package com.mentor.mentorOnDemand.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.apache.tomcat.jni.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.mentor.mentorOnDemand.dao.LoginDao;
import com.mentor.mentorOnDemand.dao.SkillDao;
import com.mentor.mentorOnDemand.dao.UserPaymentDao;
import com.mentor.mentorOnDemand.model.Admin;
import com.mentor.mentorOnDemand.model.Login;
import com.mentor.mentorOnDemand.model.Mentor;
import com.mentor.mentorOnDemand.model.Skills;
import com.mentor.mentorOnDemand.model.UserPayment;
import com.mentor.mentorOnDemand.service.AdminService;
import com.mentor.mentorOnDemand.service.LoginService;

@Controller
public class AdminController {

	@Autowired
	private AdminService adminService;
	
	@Autowired
	private LoginDao loginDao;
	
	@Autowired
	private SkillDao skillsDao;
	
	@Autowired
	private UserPaymentDao userPaymentDao;
	

	@RequestMapping(value = "/adminLogin", method = RequestMethod.GET)
    public ModelAndView home(ModelMap model)
	{
		
		Mentor mentor= new Mentor();
		model.addAttribute("mentor",mentor);
		return new ModelAndView("adminLogin");
	}
	
	@RequestMapping(value = "/register", method = RequestMethod.GET)
    public String adminsRegistration(ModelMap model)
	{
		Admin admin = new Admin();
		System.out.print("******************************");
		model.addAttribute("admin",admin);
		return "adminRegistration";
	}
	
	@RequestMapping(value = "/adminRegistration", method = RequestMethod.POST)
	public String formHandler(@ModelAttribute("admin") Admin admin,BindingResult result, 
			 Model model)
	{
		
		if(result.hasErrors())
		{
		    System.out.println("error");
			model.addAttribute("admin",admin);
			
			return "adminRegistration";
		}
		try
		{
	   Mentor mentor = new Mentor();
	   model.addAttribute("mentor",mentor);
		adminService.insertAdmin(admin);
		 
		Login loginDetails= loginDao.save(new Login(admin));
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	    return "adminLogin";
	}
	
	@RequestMapping(value= "/getRole/addSkills" ,method = RequestMethod.GET)
	public String addSkills(Model model)
	{
		
		Skills skills= new Skills();
		System.out.print("******************************");
		model.addAttribute("skills",skills);
		return "addSkill";
		
	}
	
	@RequestMapping(value= "/getRole/addSkillProcess" ,method = RequestMethod.POST)
	public String addSkillProcess(@ModelAttribute("skills") Skills skills,Model model)
	{
		
		skillsDao.save(skills);
		return "adminLandingPage";
		
	}
	
	@RequestMapping(value= "/getRole/userPayments")
	public String userPayment(HttpServletRequest request)
	{
		List<UserPayment> userPayment = new ArrayList<UserPayment>();
		userPayment= userPaymentDao.findByStatus("paid");
		if(userPayment!=null)
		{
		request.setAttribute("userPayment",userPayment);
		return "userPayments";
		}
		else
		{
			return "proposeRequest";
		}
	}
}
