package com.mentor.mentorOnDemand.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.mentor.mentorOnDemand.dao.LoginDao;
import com.mentor.mentorOnDemand.dao.ProposalRequestDao;
import com.mentor.mentorOnDemand.dao.SkillDao;
import com.mentor.mentorOnDemand.dao.UserPaymentDao;
import com.mentor.mentorOnDemand.model.Admin;
import com.mentor.mentorOnDemand.model.Login;
import com.mentor.mentorOnDemand.model.Mentor;
import com.mentor.mentorOnDemand.model.ProposalRequest;
import com.mentor.mentorOnDemand.model.Skills;
import com.mentor.mentorOnDemand.model.UserPayment;
import com.mentor.mentorOnDemand.service.MentorService;
import com.mentor.mentorOnDemand.service.ProposalRequestService;

@Controller
public class MentorController {

	@Autowired
	private MentorService mentorService;
	
	@Autowired
	private ProposalRequestService proposalRequestService;
	
	@Autowired
	private LoginDao loginDao;
	
	@Autowired
	private SkillDao skillDao;
	
	@Autowired
	private ProposalRequestDao proposalRequestDao;
	

	
	@Autowired
	private UserPaymentDao userPaymentDao;
	
	@RequestMapping(value = "/registerMentor", method = RequestMethod.GET)
    public String adminsRegistration(ModelMap model)
	{
		Mentor mentor = new Mentor();
		System.out.print("******************************");
		model.addAttribute("mentor",mentor);
		return "mentorRegistration";
	}
	
	@RequestMapping(value = "/searchMentor", method = RequestMethod.GET)
    public String searchMentor(@ModelAttribute("mentor") Mentor mentor, ModelMap model,HttpServletRequest request)
	{
		
		List<Mentor> mentors = new ArrayList<Mentor>();
		System.out.println(mentor.getRegDateTime());
		String time=mentor.getRegDateTime();
		String skill =mentor.getSkills();
		System.out.println(time);
		System.out.println(skill);
	      mentors =mentorService.getMentors(time,skill);
	      request.setAttribute("mentors",mentors);
		return "findTechnologyAndTime";
	}
	
	
	@RequestMapping(path="/sendProposal")
	public String edit(@RequestParam("mentorId") long id, ModelMap model,HttpServletRequest request) 
	{
		HttpSession session =request.getSession(false);
	     long userId = (long)session.getAttribute("userId");
		ProposalRequest proposalRequest = new ProposalRequest();
		System.out.println("mentor Id "+id);
		System.out.println("mentor Id "+userId);
		proposalRequest.setMentorId(id);
		proposalRequest.setUserId(userId);
		
		proposalRequestService.proposeMentor(proposalRequest);
		return "proposeRequest";
		
	}
	
	@RequestMapping(path="/proposalList")
	public String proposalList(HttpServletRequest request)
	{
		List<ProposalRequest> pr = new ArrayList<ProposalRequest>();
		HttpSession session =request.getSession(false);
		long userId = (long)session.getAttribute("userId");
		System.out.println("hiiiii "+userId);
		pr = proposalRequestService.findByMentorId(userId);
		request.setAttribute("pr",pr);
		return "listOfProposals";
		
	}
	
	@RequestMapping(path="/approveProposal")
	public String approveProposals(@RequestParam("uId") long id, HttpServletRequest request)
	{
		Skills skills = new Skills();
		UserPayment userPayment = new UserPayment();
		ProposalRequest proposalRequest = new ProposalRequest();
		HttpSession session =request.getSession(false);
		long mentorId = (long)session.getAttribute("userId");
		String skill= mentorService.getMentorSkill(mentorId);
		proposalRequest =proposalRequestDao.findByMentorIdAndUserId(mentorId,id);
		proposalRequest.setStatus("accept");
		proposalRequestDao.save(proposalRequest);
		 skills =skillDao.findBySkillName(skill);
		
		 userPayment.setMentorId(mentorId);
		 userPayment.setUserId(id);
		 userPayment.setPaymentAmount(skills.getBaseAmount());
		 userPayment.setSkillId(skills.getSkillId());
		 userPayment.setStatus("Not Payed");
		 userPaymentDao.save(userPayment);
		return "proposeRequest";
	}
	
	@RequestMapping(path="/rejectProposal")
	public String rejectProposals(@RequestParam("uId") long id, HttpServletRequest request)
	{
		Skills skills = new Skills();
		UserPayment userPayment = new UserPayment();
		ProposalRequest proposalRequest = new ProposalRequest();
		HttpSession session =request.getSession(false);
		long mentorId = (long)session.getAttribute("userId");
		String skill= mentorService.getMentorSkill(mentorId);
		proposalRequest =proposalRequestDao.findByMentorIdAndUserId(mentorId,id);
		proposalRequest.setStatus("reject");
		proposalRequestDao.save(proposalRequest);
		 
		return "proposeRequest";
	}
	
	
	@RequestMapping(value = "/mentorRegistration", method = RequestMethod.POST)
	public String formHandler(@ModelAttribute("mentor") Mentor mentor,BindingResult result, 
			 Model model)
	{
		
		if(result.hasErrors())
		{
		    System.out.println("error");
			model.addAttribute("mentor",mentor);
			return "mentorRegistration";
		}
		try
		{
			Login loginDetails= loginDao.save(new Login(mentor));
			System.out.println(mentor.getEmail());
		mentorService.insertMentor(mentor);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	    return "adminLogin";
	}
	
	
}
