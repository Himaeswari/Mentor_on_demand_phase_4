package com.mentor.mentorOnDemand.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.mentor.mentorOnDemand.model.Admin;
import com.mentor.mentorOnDemand.model.ProposalRequest;

@Repository
public interface ProposalRequestDao extends JpaRepository<ProposalRequest,Long>{

	@Query("Select m from ProposalRequest m where m.mentorId= :userId")
	List<ProposalRequest> findByMentorId(@Param("userId") long userId);

	ProposalRequest findByMentorIdAndUserId(long mentorId, long id);

	
}
