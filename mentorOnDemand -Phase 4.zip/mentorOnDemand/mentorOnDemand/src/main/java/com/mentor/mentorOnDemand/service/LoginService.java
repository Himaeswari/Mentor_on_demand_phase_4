package com.mentor.mentorOnDemand.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mentor.mentorOnDemand.dao.LoginDao;
import com.mentor.mentorOnDemand.model.Login;

@Service
public class LoginService {

	
	@Autowired
	private LoginDao loginDao;
	
	public void insertLogin(Login login) {
		
		loginDao.save(login);
	}

}
