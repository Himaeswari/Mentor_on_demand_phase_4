package com.mentor.mentorOnDemand.service;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mentor.mentorOnDemand.dao.AdminDao;
import com.mentor.mentorOnDemand.model.Admin;

@Service
public class AdminService {

	@Autowired 
	AdminDao adminDao;
	
	public void insertAdmin(Admin admin) {
		adminDao.save(admin);
	}

	public long getAdminId(String emails) {
		
		return adminDao.getAdminId(emails);
	}

}
